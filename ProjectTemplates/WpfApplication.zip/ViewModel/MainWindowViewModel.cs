﻿namespace $safeprojectname$.ViewModel
{
    /// <summary>
    /// Provides the logic for the <see cref="View.MainWindow"/>
    /// </summary>
    public sealed class MainWindowViewModel : ViewModelBase
    {
    }
}
