﻿/*
    Author:        /
    Changed by:    /
    Creation date: /
    Change date:   /
    Description:   DESCRIPTION OF THE PROCEDURE
    Used by:       Systems / Programs which are using the procedure
    Examples:      Example call if needed
*/